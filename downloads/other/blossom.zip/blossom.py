from pymel.core import *
import random
#f=newFile(f=1)
select('*Shader')
delete()
if (len(ls('flowerShader')) == 0):
    flowerShader = createSurfaceShader('lambert', 'flowerShader')
    treeShader = createSurfaceShader('lambert', 'treeShader')

if (len(ls('blossom*')) > 0):
    select('blossom*')
    delete()
    
delete(ls('flowerShaderSG*'))
tree = ls('tree_base')[0]

setAttr('flowerShader.color', [0.954, 0.75, 0.91])
setAttr('treeShader.color', [0.08, 0.035, 0.0])
if True:
    select(tree)
    hyperShade(assign='treeShader')
    #polyAutoProjection('testCube' +'Shape.f[*]')
    k = 0.25
    x = 0
    
    
    for f in tree.f:
        areaLeft = f.getArea(space = 'world') - k * random.random() 
        while areaLeft > 0.0:
            pointArray = f.getPoints(space='world')
    
            rand1 = random.random()
            rand2 = random.random()
            rand3 = random.random()# * 0.8 + 0.1
            
            p1 = (1.0 - rand1) * pointArray[0] + rand1 * pointArray[1]
            p2 = (1.0 - rand2) * pointArray[2] + rand2 * pointArray[3]
            totalPoint = (1.0 - rand3) * p1 + rand3 * p2
            
            #totalRand = 0.0
            #totalPoint = [0.0, 0.0, 0.0]
            #for v in f.getPoints(space='world'):
            #    rand = random.random();
            #    totalPoint = totalPoint + rand * v
            #    #print(v)
            #    totalRand = totalRand + rand
            #totalPoint = (totalPoint / totalRand)
            
            name = 'blossom' + str(x)
            duplicate(ls('copyBlossom')[0], n=name)
            cyl = ls(name)[0]
            randScale = (random.random() + 0.5) * 0.15
            scale(name, [randScale * 0.876, randScale * 0.143, randScale * 0.876])
            cyl.setRotatePivot([0.0, -0.5, 0.0], space='preTransform')
            move(name, totalPoint, rpr=True)
            angles = angleBetween(v2=f.getNormal(space='world'), v1=[0.0, 1.0, 0.0], er=True)
            rotate(name, [0.0, 360 * random.random(), 0.0])
            rotate(name, angles, r=True)
            x = x + 1
            select(cyl)
            hyperShade(assign='flowerShader')
            select(cl=True)
            areaLeft = areaLeft - k * random.random()     
        select(cl=True)
    print(str(x) + " flowers.")