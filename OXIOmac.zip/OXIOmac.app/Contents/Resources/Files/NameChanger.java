import java.io.*;


public class NameChanger
{
   public static void main(String[] ar)
   {
      for (int x = 0; x <= 10; x++)
      {
         for (int y = 0; y <= 13; y++)
         {
            File f1 = new File("Level" + x + "." + y + "/Triangle.txt");
            File f2 = new File("Level" + x + "." + y + "/Track.txt");
            if (f1.exists())
            {
               f1.renameTo(f2);
            }
         }
      }
   }
}